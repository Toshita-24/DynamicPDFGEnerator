package com.dynamicpdfgeneration.dynamicpdfgeneration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DynamicpdfgenerationApplicationTests {

	@Test
	void contextLoads() {
	}

}
