package com.dynamicpdfgeneration.dynamicpdfgeneration.service;

import com.dynamicpdfgeneration.dynamicpdfgeneration.model.InvoiceRequest;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import org.springframework.stereotype.Service;


@Service
public class PdfGeneratorService {
    public String generatePdf(InvoiceRequest request) throws Exception {
        String filePath = "invoices/" + request.getBuyer() + "_invoice.pdf";
        
        // Check if PDF already exists (add logic to check local storage)
        
        PdfWriter writer = new PdfWriter(filePath);
        com.itextpdf.kernel.pdf.PdfDocument pdf = new com.itextpdf.kernel.pdf.PdfDocument(writer);
        Document document = new Document(pdf);
        
        // Add content using iText
        document.add(new Paragraph("Seller: " + request.getSeller()));
        document.add(new Paragraph("Buyer: " + request.getBuyer()));
        // Add more structured content

        document.close();
        return filePath;
    }
}
