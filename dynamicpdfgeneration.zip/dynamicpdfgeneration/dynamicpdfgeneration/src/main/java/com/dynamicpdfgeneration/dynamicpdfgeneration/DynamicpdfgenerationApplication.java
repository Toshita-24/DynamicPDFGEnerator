package com.dynamicpdfgeneration.dynamicpdfgeneration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DynamicpdfgenerationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DynamicpdfgenerationApplication.class, args);
		System.out.println(" Dynamic PDF Generation App");
	}

}
