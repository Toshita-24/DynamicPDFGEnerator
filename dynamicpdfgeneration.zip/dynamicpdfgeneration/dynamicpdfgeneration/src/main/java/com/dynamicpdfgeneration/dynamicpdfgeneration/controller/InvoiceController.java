package com.dynamicpdfgeneration.dynamicpdfgeneration.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.dynamicpdfgeneration.dynamicpdfgeneration.model.InvoiceRequest;
import com.dynamicpdfgeneration.dynamicpdfgeneration.service.PdfGeneratorService;

import org.springframework.http.ResponseEntity;
import java.io.File;
import java.nio.file.Files;

@RestController
@RequestMapping("/api/invoice")
public class InvoiceController {

    @Autowired
    private PdfGeneratorService pdfGeneratorService;

    @PostMapping("/generate")
    public ResponseEntity<byte[]> generateInvoice(@RequestBody InvoiceRequest request) throws Exception {
        String pdfPath = pdfGeneratorService.generatePdf(request);

        File pdfFile = new File(pdfPath);
        byte[] pdfContent = Files.readAllBytes(pdfFile.toPath());
        
        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=" + pdfFile.getName())
                .body(pdfContent);
    }
}

